///////////////////////////////////////////////////////////////////////
///// Projet         : ROetIA-CrazyCubes     //////
///// Auteur         : Nicolas Vidal               //////
///// Derni�re Modif : 2013-12-28             //////
///////////////////////////////////////////////////////////////////////

using UnityEngine;
using System.Linq;
using System.Collections;

/// <summary>
/// Les �tudiants provenant de divers horizons, nous n'utiliserons pas
/// d'architecture objet et impl�menterons toutes nos m�thodes et 
/// algorithmes dans une seule classe.
/// </summary>
using System.Collections.Generic;


public class MainScript : MonoBehaviour
{
	/// <summary>
	/// Notre ensemble de composant Transform correspondant � la localisation
	/// de chacun de nos cubes dans la sc�ne, cette variable est initialis�e par
	/// Unity Dans l'�diteur (Drag'n'Drop de l'ensemble de cubes ...).
	/// </summary>
	public Transform[] _cubes;

    /// <summary>
    /// Cette m�thode est automatiquement appel�e au d�marrage de la sc�ne
    /// lorsque ce script est attach� � un objet pr�sent dans la sc�ne
    /// Dans cette m�thode, nous r�cup�rons les diff�rents
    /// cubes de notre sc�ne, m�langeons la configuration initiale et 
    /// d�marrons la r�solution avec un des trois algorithmes vus en cours :
    ///  - Recherche Local Na�ve (�quivalente � la descente de gradient sur ce probl�me)
    ///  - Recuit Simul�
    ///  - Algorithme G�n�tique
    /// </summary>
    /// <returns></returns>
    IEnumerator Start()
    {
        ///Affichage dans la console de Debug de l'erreur courante avant le m�lange.
        ///Si les cubes sont align�s, ceci doit afficher 0.
        Debug.Log("Erreur Avant Melange : " + GetError());

        ///D�marrage en pseudo asynchrone du m�lange.
        yield return StartCoroutine(Shuffle());

        ///Affichage de l'erreur apr�s m�lange, ceci doit en g�n�ral sauf cas
        ///exceptionnel afficher un nombre sup�rieur � 0.
        Debug.Log("Erreur Apr�s Melange : " + GetError());

        ///Interruption de la m�thode durant 2 secondes pour nous permettre
        ///de distinguer le m�lange du d�but de l'algorithme de r�solution
        yield return new WaitForSeconds(2f);


        #region D�marrage d'un des algorithmes de r�solution

        ///D�marrage en pseudo asynchrone de la recherche locale na�ve
        StartCoroutine(NaiveLocalSearch());

        ///D�marrage en pseudo asynchrone du recuit simul�
        //StartCoroutine(SimulatedAnnealing());

        ///D�marrage en pseudo asynchrone de l'algorithme g�n�tique
        //yield return StartCoroutine(GeneticAlgorithm());

        #endregion

    }

    #region Partie Sp�cifique � l'algorithme g�n�tique

    /// <summary>
    /// M�thode principale dans laquelle nous d�roulerons les 
    /// principales �tapes de l'algorithme g�n�tique : 
    /// - Initialisation de la population
    /// - R�p�ter :
    ///     - Evaluation de la population courante
    ///     - S�lection des reproducteurs
    ///     - Cr�ation d'une nouvelle population via Croisement
    ///     - Mutation de la nouvelle population
    /// </summary>
    /// <returns></returns>
    IEnumerator GeneticAlgorithm()
    {
        #region Param�tres

        ///La taille de la population
        int popsize = 50;

        ///Le nombre d'individus s�l�ctionn�s pour la reproduction
        ///(ici 40% de la taille de la population)
        int numSelection = (int)(popsize * 0.4f);

        ///Le taux de mutation (c.�.d. la chance avec laquelle un
        ///individu issu du croisement peut subir une mutation)
        float mutationRate = 0.4f;
        #endregion

        #region Initialisation de la population

        ///Initialisation du tableau contenant notre population initiale
        Vector3[][] population = new Vector3[popsize][];

        ///Pour chaque individu que l'on doit cr�er dans la population initiale
        for (int j = 0; j < popsize; j++)
        {
            ///M�lange de nos cubes en vue d'obtenir une autre solution
            ///al�atoire.
			Shuffle();

			//Initialisation de l'individu
			population[j] = new Vector3[_cubes.Length];

			///Stockage d'une copie d'une configuration al�atoire des cubes
			for (int i = 0; i < _cubes.Length; i++)
	            population[j][i] = _cubes[i].position;
        }

        #endregion

        ///Tout pendant que la configuration optimale n'est pas trouv�e
        while (GetError() != 0)
        {
            #region Evaluation de la population

            ///Initialisation du dictionnaire destin� � contenir l'ensemble des
            ///couples configuration/score une fois la population �valu�e
            var scoredIndividuals = new Dictionary<Vector3[], int>();

            ///Pour chaque individu de notre population � �valuer
            for (int i = 0; i < population.Length; i++)
            {
                ///Avant de proc�der � l'appel de notre oracle (GetError())
                ///Il est n�cessaire de positionner les cubes dans la 
                ///configuration propos�e par la solution �valu�e.
                for (int j = 0; j < _cubes.Length; j++)
                {
                    _cubes[j].position = population[i][j];
                }

                ///Cr�ation d'un couple configuration/solution et stockage
                ///du score obtenu pour la configuration �valu�e.
				scoredIndividuals.Add(population[i], GetError());
            }

            #endregion

            #region Selection des reproducteurs

            ///R�cup�ration de mani�re concise (gr�ce � Linq) des reproducteurs :
            /// - Tri de l'ensemble des couples configuration/score par ordre 
            ///   croissant de score.
            /// - R�cup�ration des meilleurs couples.
            /// - R�cup�ration des meilleurs configurations.
            /// - Stockage des meilleures configurations dans un tableau
            var bestIndividuals = scoredIndividuals
                .OrderBy((scoredindi) => scoredindi.Value)
                .Take(numSelection)
                .Select((scoredindi2) => scoredindi2.Key)
                .ToArray();

            #endregion

            #region Affichage du meilleur individu

            ///Pour mieux visualiser l'�volution de l'algorithme, nous
            ///remettons l'ensemble des cubes dans la configuration du
            ///meilleur individu de la g�n�ration courante (le premier
            ///des reroducteurs).
            for (int j = 0; j < _cubes.Length; j++)
            {
                _cubes[j].position = bestIndividuals[0][j];
            }

            ///Affichage Dans la console de Debug du score du meilleur
            ///individu.
            Debug.Log("Meilleur Score de la g�n�ration courante : " + GetError());

            #endregion

            #region Croisement de la population

            ///Initialisation de la nouvelle population qui va �tre g�n�r�e
            ///par croisement.
            Vector3[][] newpopulation = new Vector3[popsize][];

            ///Pour chaque enfant que l'on doit g�n�rer par croisement
            for (int i = 0; i < popsize; i++)
            {
                ///R�cup�ration de deux reproduteurs au hasard
                var parent1 = bestIndividuals[Random.Range(0, bestIndividuals.Length)];
                var parent2 = bestIndividuals[Random.Range(0, bestIndividuals.Length)];

                ///Cr�ation d'un individu � partir du croisement des deux parents
                newpopulation[i] = Crossover(parent1, parent2);
            }

            #endregion

            #region Mutation de la population

            ///Pour chaque individu de la population
            for (int i = 0; i < popsize; i++)
            {
                ///Tirage d'un nombre au hasard entre 0f et 1f
                float rdm = Random.Range(0f, 1f);

                ///Comparaison de ce nombre au taux de mutation
                ///S'il est inf�rieur, on proc�de � la mutation
                if (rdm < mutationRate)
                {
                    ///Mutation propos�e :
                    ///Inversion de deux positions

                    var pos1index = Random.Range(0, newpopulation[i].Length);
                    var pos2index = Random.Range(0, newpopulation[i].Length);

                    var pos1 = newpopulation[i][pos1index];
                    var pos2 = newpopulation[i][pos2index];

                    newpopulation[i][pos1index] = pos2;
                    newpopulation[i][pos2index] = pos1;
                }
            }

            #endregion

            ///Remplacement de l'ancienne population par la nouvelle
            population = newpopulation;

            ///On redonne la main � Unity pendant un temps r�duit
            ///pour pouvoir contr�ler la simulation et pour visualiser
            ///l'�volution de l'algorithme.
            yield return new WaitForSeconds(0.0001f);
        }

        ///Fin de l'algorithme g�n�tique
        yield return null;
    }

    /// <summary>
    /// M�thode proposant une m�thode pour obtenir une nouvel
    /// individu par croisement de deux configurations parentes
    /// </summary>
    /// <param name="parent1">Le parent 1</param>
    /// <param name="parent2">Le parent 2</param>
    /// <returns>L'enfant g�n�r� par croisement</returns>
    Vector3[] Crossover(Vector3[] parent1, Vector3[] parent2)
    {
        ///L'index pointant sur une position au sein des parents
        int iParents = 0;

        ///Variable indiquant si l'on cherche � copier une position
        ///du parent1 ou du parent 2 dans l'enfant.
        bool lookingAtParent1 = true;

        ///Initialisation de l'enfant.
        var child = new Vector3[parent1.Length];

        ///On remplit dans l'enfant des positions non utilis�es par
        ///les cubes pour �viter une boucle infinie.
        for (int k = 0; k < child.Length; k++)
            child[k] = new Vector3(-42, -42, -42);

        ///Pour chaque position � remplir dans l'enfant.
        for (int i = 0; i < child.Length; i++)
        {
            ///Si l'on souhaite copier une position du premier parent
            ///dans l'enfant.
            if (lookingAtParent1)
            {
                ///Si la position du parent1 n'est pas d�j� pr�sente dans l'enfant.
                if (!child.Contains(parent1[iParents]))
                {
                    ///On copie la position courante du parent1 dans l'enfant.
                    child[i] = parent1[iParents];

                    ///On pr�cise qu'au tour du boucle suivant nous chercherons
                    ///� copier une position provenant du deuxi�me parent.
                    lookingAtParent1 = false;
                }
                ///Sinon, si la position du parent2 n'est pas pr�sente dans l'enfant.
                else if (!child.Contains(parent2[iParents]))
                {
                    ///On copie la position du parent2 dans l'enfant.
                    child[i] = parent2[iParents];

                    ///On pr�cise qu'au tour du boucle suivant nous chercherons
                    ///� copier une position provenant du premier parent.
                    lookingAtParent1 = true;
                }
                ///Si les deux positions du parent1 et du parent2 sont d�j� pr�sentes
                ///dans l'enfant.
                else
                {
                    ///On d�cr�mente pr�ventivement l'index de l'enfant.
                    i--;
                }
                ///On incr�mente l'index des parents
                iParents++;

                ///Tout en v�rifiant que l'on ne d�passe pas la taille du tableau
                ///des parents, si tel est le cas, on remet � z�ro cet index.
                if (iParents >= parent1.Length)
                    iParents = 0;
            }
            ///Si l'on souhaite copier une position du parent2 en premier
            else
            {
                ///Si la position du parent2 n'est pas d�j� pr�sente dans l'enfant.
                if (!child.Contains(parent2[iParents]))
                {
                    ///On copie la position du parent2 dans l'enfant.
                    child[i] = parent2[iParents];

                    ///On pr�cise qu'au tour du boucle suivant nous chercherons
                    ///� copier une position provenant du premier parent.
                    lookingAtParent1 = true;
                }
                ///Sinon, si la position du parent1 n'est pas pr�sente dans l'enfant.
                else if (!child.Contains(parent1[iParents]))
                {
                    ///On copie la position courante du parent1 dans l'enfant.
                    child[i] = parent1[iParents];

                    ///On pr�cise qu'au tour du boucle suivant nous chercherons
                    ///� copier une position provenant du deuxi�me parent.
                    lookingAtParent1 = false;
                }
                ///Si les deux positions du parent1 et du parent2 sont d�j� pr�sentes
                ///dans l'enfant.
                else
                {
                    ///On d�cr�mente pr�ventivement l'index de l'enfant.
                    i--;
                }
                ///On incr�mente l'index des parents
                iParents++;

                ///Tout en v�rifiant que l'on ne d�passe pas la taille du tableau
                ///des parents, si tel est le cas, on remet � z�ro cet index.
                if (iParents >= parent1.Length)
                    iParents = 0;
            }
        }

        ///Une fois le croisement effectu�, on renvoie l'enfant ainsi g�n�r�.
        return child;
    }

    #endregion

    #region Partie sp�cifique au Recuit Simul�

    /// <summary>
    /// M�thode proposant une impl�mentation des diff�rentes �tapes li�es
    /// � l'algorithme du recuit simul�.
    /// </summary>
    /// <returns></returns>
    IEnumerator SimulatedAnnealing()
    {
        ///R�cup�ration de l'erreur initiale.
        int currentError = GetError();

        ///Initialisation de la temp�rature � une valeur 'plutot basse'.
        float temperature = 2f;

        ///Initialisation de la meilleure erreur obtenue � l'erreur initiale.
        int bestError = currentError;

        ///Initialisation de la valeur de 'stagnation' qui si elle d�passe un
        ///certain seuil provoquera l'augmentation de la temp�rature.
        float stagnation = 0.001f;

        ///Tout pendant que l'erreur n'est pas nulle (que les cubes ne sont pas align�s)
        while (currentError != 0)
        {
            #region Permutation de deux cubes adjacents (c�te � c�te ou l'un au dessus de l'autre)

            ///On r�cup�re deux cubes au hasard
            var cube1 = _cubes[Random.Range(0, _cubes.Length)];
            var cube2 = _cubes[Random.Range(0, _cubes.Length)];

            ///Tout pendant qu'ils ne sont pas adjacents, on retire le deuxi�me
            ///Il est clair que cela n'est pas optimal comme m�thode, mais largement
            ///suffisant pour nos besoins.
            while (!AreNeighbours(cube1, cube2))
            {
                cube2 = _cubes[Random.Range(0, _cubes.Length)];
            }

            ///Permutation des position des deux cubes.
            SwapCubes(cube1, cube2);

            #endregion

            ///R�cup�ration de la nouvelle erreur.
            int newError = GetError();

            ///Tirage d'un nombre al�atoire entre 0f et 1f.
            float rdm = Random.Range(0f, 1f);

            ///Comparaison de ce nombre � la probabilit� d'accepter un changement
            ///d�termin�e par la r�gle de Metropolis.
            if (rdm < GetProbability(temperature, currentError, newError))
            {
                ///Si le nombre est inf�rieur, on accepte la permutation
                ///et l'on met � jour l'erreur courante.
                currentError = newError;
            }
            else
            {
                ///Sinon on d�fait la permutation.
                SwapCubes(cube1, cube2);
            }

            ///Si l'erreur stagne
            if (bestError == currentError)
            {
                ///On incr�mente la stagnation
                stagnation *= 1.001f;
            }
            else
            {
                ///Sinon on la r�initialise
                stagnation = 0.001f;
            }

            ///Si l'erreur diminue en de�a de la meilleure erreur obtenue
            if (currentError < bestError)
            {
                ///On met � jour la meilleure erreur obtenue
                bestError = currentError;

                ///On r�initialise la stagnation
                stagnation = 0.001f;
            }

            ///On met � jour la temperature � chaque tour de boucle :
            /// - si la stagnation est suffisante la temperature va augmenter
            /// - sinon la temperature d�croit de mani�re g�om�trique
            temperature *= 0.998f + stagnation;

            ///Affichage dans la console de Debug du couple temperature stagnation
            ///pour pouvoir �tre t�moin de l'augmentation de la temp�rature lorsque
            ///l'on se retrouve coinc� trop longtemps dans un minimum local.
            Debug.Log(temperature + "  -  " + stagnation);

            ///On rend la main � Unity pendant un court laps de temps pour permettre
            ///le contr�le de la simulation ainsi que la visualisation de l'�volution
            ///de l'algorithme.
            yield return new WaitForSeconds(0.0001f);
        }
    }

    /// <summary>
    /// Proposition d'impl�mentation de la r�gle de Metorpolis repr�sentant une
    /// fonction seuil, renvoyant la probabilit� d'accepter une permutation
    /// selon la diff�rence entre l'erreur courante et la nouvelle erreur et
    /// ainsi qu'en fonction de la temperature courante.
    /// </summary>
    /// <param name="temperature"></param>
    /// <param name="currentError"></param>
    /// <param name="newError"></param>
    /// <returns></returns>
    float GetProbability(float temperature, int currentError, int newError)
    {
        ///Si la temperature est nulle
        ///cas particulier pour �viter une division par z�ro
        if (temperature == 0)
        {
            return (currentError - newError) >= 0 ? 1 : 0;
        }

        ///Regle de Metropolis
        return Mathf.Exp(((float)(currentError - newError)) / temperature);
    }

    #endregion

    #region Partie sp�cifique � la recherche locale na�ve

    /// <summary>
    /// Dans cette m�thode nous impl�mentons les diff�rentes �tapes
    /// li�es � la recherche locale na�ve pouvant s'apparenter � une
    /// descente de gradient sur le probl�me pr�sent.
    /// </summary>
    /// <returns></returns>
    IEnumerator NaiveLocalSearch()
    {
        ///R�cup�ration de l'erreur courante
        int currentError = GetError();

        ///Tout pendant que l'erreur n'est pas � z�ro (que les cubes ne
        ///sont pas align�s)
        while (currentError != 0)
        {
            ///On r�cup�re deux cubes au hasard
            var cube1 = _cubes[Random.Range(0, _cubes.Length)];
            var cube2 = _cubes[Random.Range(0, _cubes.Length)];

            ///Tout pendant qu'ils ne sont pas adjacents, on retire le deuxi�me
            ///Il est clair que cela n'est pas optimal comme m�thode, mais largement
            ///suffisant pour nos besoins.
            while (!AreNeighbours(cube1, cube2))
            {
                cube2 = _cubes[Random.Range(0, _cubes.Length)];
            }

            ///On �change la position des deux cubes adjacents
            SwapCubes(cube1, cube2);

            ///R�cup�ration de la nouvelle erreur
            int newError = GetError();

            ///Si l'erreur a augment�
            if (newError > currentError)
            {
                ///On d�fait la permutation
                SwapCubes(cube1, cube2);
            }
            ///Sinon
            else
            {
                ///On met � jour l'erreur courante
                currentError = newError;
            }

            ///On rend la main � Unity pendant un court laps de temps
            yield return new WaitForSeconds(0.0001f);
        }
    }

    #endregion

    #region Partie commune aux deux algorithmes de la cat�gorie recherche locale

    /// <summary>
    /// Methode testant si deux cubes sont adjacents
    /// </summary>
    /// <param name="cube1"></param>
    /// <param name="cube2"></param>
    /// <returns></returns>
    bool AreNeighbours(Transform cube1, Transform cube2)
    {
        ///Si les cubes sont c�te � cote
        if (Mathf.Abs(cube1.position.x -
            cube2.position.x) == 2 &&
            cube1.position.y == cube2.position.y &&
            cube1.position.z == cube2.position.z)
            return true;

        ///Si les cubes sont l'un au dessus de l'autre
        if (Mathf.Abs(cube1.position.y -
            cube2.position.y) == 2 &&
            cube1.position.x == cube2.position.x &&
            cube1.position.z == cube2.position.z)
            return true;

        ///Si ils sont l'un derri�re l'autre (si l'on souhaite non
        ///plus aligner des lignes, mais des couches de cubes)
        if (Mathf.Abs(cube1.position.z - cube2.position.z) == 2 &&
            cube1.position.x == cube2.position.x &&
            cube1.position.y == cube2.position.y)
            return true;

        ///Sinon ils ne sont pas adjacents
        return false;
    }

    #endregion

    #region partie commune aux trois algorithmes

    /// <summary>
    /// Cette m�thode repr�sente notre oracle (le seul � avoir le droit
    /// d'acc�der � la couleur des cubes) et nous renvoit le score d'une
    /// configuration donn�e.
    /// </summary>
    /// <returns></returns>
    int GetError()
    {
        ///On initialise l'erreur � z�ro
        int error = 0;

        ///On incr�mente l'erreur pour chaque couple de cube de m�me couleur
        ///n'�tant pas � la m�me hauteur.
        foreach (var cube1 in _cubes)
            foreach (var cube2 in _cubes)
                if (cube1.tag == cube2.tag && cube1.position.y != cube2.position.y)
                    error++;

        ///On renvoit l'erreur ainsi calcul�e.
        return error;
    }

    #endregion

    #region Manipulation des cubes

    /// <summary>
    /// Coroutine m�langeant les cubes uniform�ment
    /// </summary>
    /// <returns></returns>
    IEnumerator Shuffle()
    {
		for (int i = 0; i < _cubes.Length; i++)
        {
            ///On choisit un cube au hasard entre le i�me et les cubes restant
            var index = Random.Range(0, _cubes.Length);

            ///On �change leurs positions
            SwapCubes(_cubes[i], _cubes[index]);

            ///On rend la main � Unity pendant un court laps de temps
            ///pour ne pas bloquer le programme.
            yield return new WaitForSeconds(0.001f);
        }
    }

	/// <summary>
	/// M�lange uniforme des positions des cubes
	/// </summary>
	/// <returns></returns>
	void InstantShuffle()
	{
		for (int i = 0; i < _cubes.Length; i++)
		{
			///On choisit un cube au hasard entre le i�me et les cubes restant
			var index = Random.Range(0, _cubes.Length);
			
			///On �change leurs positions
			SwapCubes(_cubes[i], _cubes[index]);
		}
	}

    /// <summary>
    /// M�thode outil nous permettant d'intervertir la position de
    /// deux cubes.
    /// </summary>
    /// <param name="cube1"></param>
    /// <param name="cube2"></param>
    void SwapCubes(Transform cube1, Transform cube2)
    {
        var temp = cube1.position;
        cube1.position = cube2.position;
        cube2.position = temp;
    }

    #endregion
}
